# KriegerMod – Fabric-Port für Minecraft 1.21.10

Port der Forge-Mod `KriegerMod 1.20.1 (0.0.8)`. Der Quellcode wurde aus dem Bytecode rekonstruiert
(es lag nur die .jar vor) und ist NICHT kompiliert/getestet.

## Bauen
1. JDK 21 installieren.
2. `gradle.properties` prüfen: exakte Versionen (loader, loom, fabric_version) von https://fabricmc.net/develop übernehmen.
3. `gradle wrapper` (einmalig) und dann `./gradlew build`
4. Ergebnis: `build/libs/KriegerMod-*.jar` in den `mods/`-Ordner von Server UND Clients (Client-Teil ist optional,
   ohne ihn fehlen nur Herz-HUD und Animation).

## Dateien (config/heartsmod/)
kriegermod-config.json, playerLives.json, spielzeit.json, duel_usage.json, dummy_state.json, dummylog.json

## Bewusst NICHT übernommen
- WebhookLogger mit Proxy auf 146.19.191.154 und VersionChecker/Blacklist (Server-Abschaltung per Fernsteuerung)
- Items linkheart/lifestealer/improvement_point (nur in Lang-Dateien, keine Klassen in 0.0.8)
- Curios-Slot und Backpack-Sperre (kein Fabric-Pendant, Lifesaver wirkt aus dem Inventar)

## Werte
Kampfdauer 30 s, Enderperlen-Limit 32, Spinnenweben-Limit 64 (ein Stack) – einstellbar in kriegermod-config.json.
Lifesaver-Event: Dauer (5 min) und Zombie-Werte sind Platzhalter, in event/LifesaverEvent.java anpassbar.
