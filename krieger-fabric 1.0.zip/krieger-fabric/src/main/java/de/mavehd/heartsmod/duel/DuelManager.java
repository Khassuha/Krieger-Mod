package de.mavehd.heartsmod.duel;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import de.mavehd.heartsmod.HeartsMod;
import de.mavehd.heartsmod.Msg;
import de.mavehd.heartsmod.config.HeartsPaths;
import de.mavehd.heartsmod.net.Net;
import de.mavehd.heartsmod.net.SyncDuelPayload;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.ClickEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.HoverEvent;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** 1v1-Duelle: Anfragen, Start/Ende, Limit von 2 gestarteten Duellen pro Spieler. */
public final class DuelManager {
    public static final int LIMIT = 2;
    private static final long MESSAGE_COOLDOWN_MS = 2000;

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Type USAGE_TYPE = new TypeToken<Map<String, Integer>>() {}.getType();

    private static final Map<UUID, UUID> ACTIVE = new HashMap<>();     // beide Richtungen
    private static final Map<UUID, UUID> REQUESTS = new HashMap<>();   // Ziel -> Anfragender
    private static final Map<UUID, Integer> USAGE = new HashMap<>();
    private static final Map<UUID, Long> LAST_MSG = new HashMap<>();
    private static boolean enabled = true;

    private DuelManager() {}

    private static Path usageFile() { return HeartsPaths.dir().resolve("duel_usage.json"); }

    public static void load() {
        try {
            if (Files.exists(usageFile())) {
                Map<String, Integer> raw = GSON.fromJson(Files.readString(usageFile()), USAGE_TYPE);
                if (raw != null) raw.forEach((k, v) -> USAGE.put(UUID.fromString(k), v));
            }
        } catch (Exception e) { HeartsMod.LOGGER.error("[KriegerMod] duel_usage laden fehlgeschlagen", e); }
    }

    public static void save() {
        try {
            Map<String, Integer> raw = new HashMap<>();
            USAGE.forEach((k, v) -> raw.put(k.toString(), v));
            Files.writeString(usageFile(), GSON.toJson(raw));
        } catch (Exception e) { HeartsMod.LOGGER.error("[KriegerMod] duel_usage speichern fehlgeschlagen", e); }
    }

    public static boolean isEnabled() { return enabled; }
    public static void setEnabled(boolean v) { enabled = v; }
    public static void resetAllUsage() { USAGE.clear(); save(); }

    public static boolean isInDuel(UUID id) { return ACTIVE.containsKey(id); }
    public static boolean isPair(UUID a, UUID b) { return b.equals(ACTIVE.get(a)); }

    /** Meldung mit 2-Sekunden-Cooldown, damit Spam beim Draufhauen vermieden wird. */
    public static void blockedMessage(ServerPlayer p, String text) {
        long now = System.currentTimeMillis();
        Long last = LAST_MSG.get(p.getUUID());
        if (last != null && now - last < MESSAGE_COOLDOWN_MS) return;
        LAST_MSG.put(p.getUUID(), now);
        Msg.send(p, text);
    }

    public static void request(ServerPlayer from, ServerPlayer to) {
        if (!enabled) { Msg.send(from, "§cDas Duel-System ist momentan deaktiviert."); return; }
        if (from.getUUID().equals(to.getUUID())) { Msg.send(from, "Du kannst kein Duel gegen dich selbst führen."); return; }
        if (isInDuel(from.getUUID()) || isInDuel(to.getUUID())) { Msg.send(from, "Einer von euch ist bereits in einem Duel."); return; }
        if (USAGE.getOrDefault(from.getUUID(), 0) >= LIMIT) { Msg.send(from, "§cDu kannst nur " + LIMIT + " Duelle starten."); return; }

        REQUESTS.put(to.getUUID(), from.getUUID());
        String name = Msg.name(from);
        Component accept = Component.literal("[Annehmen]").withStyle(s -> s.withColor(ChatFormatting.GREEN)
                .withClickEvent(new ClickEvent.RunCommand("/duel accept " + name))
                .withHoverEvent(new HoverEvent.ShowText(Component.literal("Annehmen"))));
        Component deny = Component.literal("[Ablehnen]").withStyle(s -> s.withColor(ChatFormatting.RED)
                .withClickEvent(new ClickEvent.RunCommand("/duel deny " + name))
                .withHoverEvent(new HoverEvent.ShowText(Component.literal("Ablehnen"))));
        to.sendSystemMessage(Component.literal("Du hast eine Duell-Anfrage von §e" + name + " §ferhalten! ")
                .append(accept).append(Component.literal(" ")).append(deny));
        Msg.send(from, "Duell-Anfrage wurde an " + Msg.name(to) + " gesendet.");
    }

    public static void accept(ServerPlayer target, ServerPlayer requester) {
        if (!enabled) { Msg.send(target, "§cDas Duel-System ist momentan deaktiviert."); return; }
        if (!requester.getUUID().equals(REQUESTS.get(target.getUUID()))) {
            Msg.send(target, "§cKeine gültige Duell-Anfrage gefunden."); return;
        }
        REQUESTS.remove(target.getUUID());
        if (isInDuel(target.getUUID()) || isInDuel(requester.getUUID())) {
            Msg.send(target, "Einer von euch ist bereits in einem Duel."); return;
        }
        Msg.send(target, "Du hast das Duell gegen §e" + Msg.name(requester) + " §aakzeptiert!");
        Msg.send(requester, "§e" + Msg.name(target) + " §ahat das Duell akzeptiert!");
        start(requester, target);
    }

    public static void deny(ServerPlayer target, ServerPlayer requester) {
        if (!requester.getUUID().equals(REQUESTS.get(target.getUUID()))) {
            Msg.send(target, "§cKeine gültige Duell-Anfrage gefunden."); return;
        }
        REQUESTS.remove(target.getUUID());
        Msg.send(target, "Du hast das Duell abgelehnt.");
        Msg.send(requester, "§e" + Msg.name(target) + " §chat das Duell abgelehnt.");
    }

    private static void start(ServerPlayer starter, ServerPlayer other) {
        ACTIVE.put(starter.getUUID(), other.getUUID());
        ACTIVE.put(other.getUUID(), starter.getUUID());
        USAGE.merge(starter.getUUID(), 1, Integer::sum);
        save();
        Net.send(starter, new SyncDuelPayload(true));
        Net.send(other, new SyncDuelPayload(true));
    }

    /** Duell beenden. winner darf null sein (z. B. bei Logout). */
    public static void end(MinecraftServer server, UUID a, UUID b, ServerPlayer winner) {
        ACTIVE.remove(a);
        ACTIVE.remove(b);
        for (UUID id : new UUID[]{a, b}) {
            ServerPlayer p = server.getPlayerList().getPlayer(id);
            if (p == null) continue;
            Net.send(p, new SyncDuelPayload(false));
            Msg.send(p, "Das Duell wurde beendet." + (winner != null ? " Sieger: §a" + Msg.name(winner) : ""));
        }
    }

    public static void onDisconnect(ServerPlayer p) {
        UUID other = ACTIVE.get(p.getUUID());
        REQUESTS.remove(p.getUUID());
        REQUESTS.values().removeIf(v -> v.equals(p.getUUID()));
        if (other != null) {
            ServerPlayer o = Msg.server(p).getPlayerList().getPlayer(other);
            end(Msg.server(p), p.getUUID(), other, o);
        }
    }
}
