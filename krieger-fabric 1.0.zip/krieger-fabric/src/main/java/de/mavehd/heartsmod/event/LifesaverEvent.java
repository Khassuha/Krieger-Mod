package de.mavehd.heartsmod.event;

import de.mavehd.heartsmod.HeartsMod;
import de.mavehd.heartsmod.Msg;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.levelgen.Heightmap;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.UUID;

/**
 * /lifesaverevent: Ein leuchtender Boss-Zombie versteckt sich im Umkreis von 500 Bloecken und droppt den
 * Lebensretter. Wird er nicht rechtzeitig gefunden, endet das Event ohne Gewinner.
 * ACHTUNG: Dauer, Zombie-Werte und Spawn-Rate sind Schaetzwerte (im Bytecode nur EVENT_RADIUS = 500 fest).
 */
public final class LifesaverEvent {
    private static final int EVENT_RADIUS = 500;
    private static final int DURATION_TICKS = 20 * 60 * 5;
    private static final Random RANDOM = new Random();

    private static boolean active;
    private static ServerLevel level;
    private static int ticksRemaining;
    private static ServerBossEvent bossbar;
    private static UUID lifesaverZombie;
    private static int forcedX, forcedZ;
    private static final List<UUID> EVENT_ZOMBIES = new ArrayList<>();

    private LifesaverEvent() {}

    public static boolean isActive() { return active; }

    public static void start(ServerLevel lvl, BlockPos origin) {
        active = true;
        level = lvl;
        ticksRemaining = DURATION_TICKS;
        bossbar = new ServerBossEvent(Component.literal("Lifesaver Event"),
                BossEvent.BossBarColor.GREEN, BossEvent.BossBarOverlay.PROGRESS);
        for (ServerPlayer p : lvl.getServer().getPlayerList().getPlayers()) bossbar.addPlayer(p);

        int x = origin.getX() + RANDOM.nextInt(EVENT_RADIUS * 2 + 1) - EVENT_RADIUS;
        int z = origin.getZ() + RANDOM.nextInt(EVENT_RADIUS * 2 + 1) - EVENT_RADIUS;
        forcedX = x >> 4;
        forcedZ = z >> 4;
        lvl.setChunkForced(forcedX, forcedZ, true);
        int y = lvl.getHeight(Heightmap.Types.MOTION_BLOCKING, x, z);

        Zombie boss = EntityType.ZOMBIE.create(lvl, EntitySpawnReason.EVENT);
        if (boss != null) {
            boss.setPos(x + 0.5, y, z + 0.5);
            boss.setGlowingTag(true);
            boss.setCustomName(Component.literal("§aLifesaver"));
            boss.setCustomNameVisible(true);
            boss.setPersistenceRequired();
            if (boss.getAttribute(Attributes.MAX_HEALTH) != null) boss.getAttribute(Attributes.MAX_HEALTH).setBaseValue(60);
            boss.setHealth(60f);
            lvl.addFreshEntity(boss);
            lifesaverZombie = boss.getUUID();
        }
        Msg.broadcast(lvl.getServer(), Msg.TAG + "Life Saver Event started!");
    }

    public static void tick(MinecraftServer server) {
        if (!active) return;
        ticksRemaining--;
        bossbar.setProgress(Math.max(0f, ticksRemaining / (float) DURATION_TICKS));
        if (ticksRemaining % 200 == 0) spawnZombiesRandomly(server);
        if (ticksRemaining <= 0) endEvent(server, false);
    }

    private static void spawnZombiesRandomly(MinecraftServer server) {
        List<ServerPlayer> players = server.getPlayerList().getPlayers();
        if (players.isEmpty() || EVENT_ZOMBIES.size() >= 20) return;
        ServerPlayer p = players.get(RANDOM.nextInt(players.size()));
        if (p.level() != level) return;
        double ang = RANDOM.nextDouble() * Math.PI * 2;
        double dist = 24 + RANDOM.nextInt(24);
        int x = (int) (p.getX() + Math.cos(ang) * dist);
        int z = (int) (p.getZ() + Math.sin(ang) * dist);
        int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING, x, z);
        Zombie zb = EntityType.ZOMBIE.create(level, EntitySpawnReason.EVENT);
        if (zb == null) return;
        zb.setPos(x + 0.5, y, z + 0.5);
        level.addFreshEntity(zb);
        EVENT_ZOMBIES.add(zb.getUUID());
    }

    public static void onJoin(ServerPlayer p) {
        if (active && bossbar != null) bossbar.addPlayer(p);
    }

    public static void onDeath(LivingEntity entity, DamageSource source) {
        if (!active || lifesaverZombie == null || !entity.getUUID().equals(lifesaverZombie)) return;
        ItemEntity drop = new ItemEntity((ServerLevel) entity.level(), entity.getX(), entity.getY(), entity.getZ(),
                new ItemStack(HeartsMod.LIFESAVER));
        drop.setDefaultPickUpDelay();
        entity.level().addFreshEntity(drop);
        endEvent(entity.level().getServer(), true);
    }

    private static void endEvent(MinecraftServer server, boolean found) {
        active = false;
        Msg.broadcast(server, found ? "§aLifesaver has been found!" : "§cEvent ended. No Lifesaver was found!");
        if (bossbar != null) { bossbar.removeAllPlayers(); bossbar = null; }
        if (level != null) {
            level.setChunkForced(forcedX, forcedZ, false);
            if (!found && lifesaverZombie != null) {
                Entity e = level.getEntity(lifesaverZombie);
                if (e != null) e.discard();
            }
        }
        lifesaverZombie = null;
        EVENT_ZOMBIES.clear();
    }
}
