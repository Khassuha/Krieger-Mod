package de.mavehd.heartsmod.net;

import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.server.level.ServerPlayer;

public final class Net {
    private Net() {}

    public static void registerPayloads() {
        PayloadTypeRegistry.playS2C().register(SyncLivesPayload.TYPE, SyncLivesPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(SyncDuelPayload.TYPE, SyncDuelPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(StartVideoPayload.TYPE, StartVideoPayload.CODEC);
    }

    /** Sendet nur, wenn der Client die Mod hat (Vanilla-Clients bleiben unberuehrt). */
    public static <T extends CustomPacketPayload> void send(ServerPlayer p, T payload) {
        if (ServerPlayNetworking.canSend(p, payload.type())) {
            ServerPlayNetworking.send(p, payload);
        }
    }
}
