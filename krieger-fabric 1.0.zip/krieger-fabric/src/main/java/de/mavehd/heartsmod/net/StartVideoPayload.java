package de.mavehd.heartsmod.net;

import de.mavehd.heartsmod.HeartsMod;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

public record StartVideoPayload() implements CustomPacketPayload {
    public static final Type<StartVideoPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(HeartsMod.MOD_ID, "start_video"));
    public static final StreamCodec<RegistryFriendlyByteBuf, StartVideoPayload> CODEC =
            StreamCodec.unit(new StartVideoPayload());

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }
}
