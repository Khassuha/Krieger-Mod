package de.mavehd.heartsmod.net;

import de.mavehd.heartsmod.HeartsMod;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

public record SyncDuelPayload(boolean inDuel) implements CustomPacketPayload {
    public static final Type<SyncDuelPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(HeartsMod.MOD_ID, "sync_duel"));
    public static final StreamCodec<RegistryFriendlyByteBuf, SyncDuelPayload> CODEC =
            StreamCodec.composite(ByteBufCodecs.BOOL, SyncDuelPayload::inDuel, SyncDuelPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }
}
