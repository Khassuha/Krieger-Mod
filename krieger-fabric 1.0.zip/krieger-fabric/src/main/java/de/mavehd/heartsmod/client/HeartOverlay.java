package de.mavehd.heartsmod.client;

import de.mavehd.heartsmod.HeartsMod;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.resources.ResourceLocation;

/** Zeigt die verbleibenden Leben als Herzreihe ueber der Hotbar (Position ggf. anpassen). */
public final class HeartOverlay {
    private static final ResourceLocation FULL =
            ResourceLocation.fromNamespaceAndPath(HeartsMod.MOD_ID, "textures/gui/heart.png");
    private static final ResourceLocation EMPTY =
            ResourceLocation.fromNamespaceAndPath(HeartsMod.MOD_ID, "textures/gui/heart_empty.png");
    private static final int SIZE = 11;

    private HeartOverlay() {}

    public static void render(GuiGraphics g, DeltaTracker delta) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui || ClientData.lives < 0) return;
        if (mc.player.isCreative() || mc.player.isSpectator()) return;

        int total = Math.max(3, ClientData.lives);
        int width = total * (SIZE + 1) - 1;
        int x = g.guiWidth() / 2 - width / 2;
        int y = g.guiHeight() - 59 - SIZE - 2;
        for (int i = 0; i < total; i++) {
            ResourceLocation tex = i < ClientData.lives ? FULL : EMPTY;
            g.blit(RenderPipelines.GUI_TEXTURED, tex, x + i * (SIZE + 1), y, 0f, 0f, SIZE, SIZE, SIZE, SIZE);
        }
        if (ClientData.inDuel) {
            g.drawCenteredString(mc.font, "§cDuell", g.guiWidth() / 2, y - 10, 0xFFFFFF);
        }
    }
}
