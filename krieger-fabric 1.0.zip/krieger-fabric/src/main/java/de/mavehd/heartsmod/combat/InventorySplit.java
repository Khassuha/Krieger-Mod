package de.mavehd.heartsmod.combat;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

/**
 * Loot-Regel bei PvP-Toden: 50 % des Inventars bleiben beim Spieler (Rueckgabe beim Respawn),
 * die uebrigen 50 % droppen normal. Entspricht CombatInventorySaver/-Restore der Forge-Version.
 * Die zurueckgehaltenen Items liegen nur im RAM (zwischen Tod und Respawn).
 */
public final class InventorySplit {
    private static final Random RANDOM = new Random();
    private static final Map<UUID, Map<Integer, ItemStack>> KEPT = new HashMap<>();

    private InventorySplit() {}

    /** Entfernt die Haelfte der Stacks aus dem Inventar und merkt sie sich. */
    public static void saveHalf(ServerPlayer p) {
        Inventory inv = p.getInventory();
        List<Integer> slots = new ArrayList<>();
        for (int i = 0; i < inv.getContainerSize(); i++) {
            if (!inv.getItem(i).isEmpty()) slots.add(i);
        }
        Collections.shuffle(slots, RANDOM);
        int keep = slots.size() / 2;
        Map<Integer, ItemStack> kept = new HashMap<>();
        for (int n = 0; n < keep; n++) {
            int slot = slots.get(n);
            kept.put(slot, inv.getItem(slot).copy());
            inv.setItem(slot, ItemStack.EMPTY);
        }
        if (!kept.isEmpty()) KEPT.put(p.getUUID(), kept);
    }

    /** Gibt die gemerkten Items nach dem Respawn zurueck. */
    public static void restore(ServerPlayer newPlayer) {
        Map<Integer, ItemStack> kept = KEPT.remove(newPlayer.getUUID());
        if (kept == null) return;
        Inventory inv = newPlayer.getInventory();
        kept.forEach((slot, stack) -> {
            if (inv.getItem(slot).isEmpty()) inv.setItem(slot, stack);
            else if (!inv.add(stack)) newPlayer.drop(stack, false);
        });
    }

    /** Fuer den Dummy-Tod: waehlt zufaellig die Haelfte der Slots, die droppen. */
    public static List<Integer> pickDropHalf(Map<Integer, ItemStack> snapshot) {
        List<Integer> slots = new ArrayList<>(snapshot.keySet());
        Collections.shuffle(slots, RANDOM);
        return new ArrayList<>(slots.subList(0, slots.size() - slots.size() / 2));
    }
}
