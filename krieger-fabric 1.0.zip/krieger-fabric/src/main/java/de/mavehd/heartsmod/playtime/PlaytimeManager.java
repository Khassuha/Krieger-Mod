package de.mavehd.heartsmod.playtime;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import de.mavehd.heartsmod.HeartsMod;
import de.mavehd.heartsmod.Msg;
import de.mavehd.heartsmod.combat.CombatManager;
import de.mavehd.heartsmod.config.HeartsConfig;
import de.mavehd.heartsmod.config.HeartsPaths;
import de.mavehd.heartsmod.dummy.DummyManager;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.BossEvent;

import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Taegliches Spielzeit-Kontingent (Standard 180 min, bis 7 Tage ansammelbar), Reset um Mitternacht Europe/Berlin. */
public final class PlaytimeManager {
    private static final ZoneId ZONE = ZoneId.of("Europe/Berlin");
    private static final long SAVE_INTERVAL_MS = 30_000;
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private static final class PData {
        long remainingMillis;
        boolean warn10, warn5, warn1, grace;
    }

    private static final class Save {
        long lastGlobalResetDay;
        boolean enabled = true;
        boolean bossbar = true;
        Map<String, Long> remaining = new HashMap<>();
    }

    private static final Map<UUID, PData> DATA = new ConcurrentHashMap<>();
    private static final Map<UUID, ServerBossEvent> BOSSBARS = new HashMap<>();
    private static long lastGlobalResetDay;
    private static boolean enabled = true;
    private static boolean bossbarEnabled = true;
    private static boolean dirty;
    private static long lastSave;

    private PlaytimeManager() {}

    private static Path file() { return HeartsPaths.dir().resolve("spielzeit.json"); }
    private static long dailyMillis() { return HeartsConfig.get().dailyMinutes * 60_000L; }
    private static long capMillis() { return dailyMillis() * Math.max(1, HeartsConfig.get().maxAccumulatedDays); }
    private static long today() { return LocalDate.now(ZONE).toEpochDay(); }

    public static boolean isEnabled() { return enabled; }
    public static void setEnabled(boolean v) { enabled = v; dirty = true; if (!v) removeAllBossbars(); }
    public static boolean isBossbarEnabled() { return bossbarEnabled; }
    public static void setBossbarEnabled(boolean v) { bossbarEnabled = v; dirty = true; if (!v) removeAllBossbars(); }

    public static void onServerStarted(MinecraftServer server) {
        try {
            if (Files.exists(file())) {
                Save s = GSON.fromJson(Files.readString(file()), Save.class);
                if (s != null) {
                    lastGlobalResetDay = s.lastGlobalResetDay;
                    enabled = s.enabled;
                    bossbarEnabled = s.bossbar;
                    s.remaining.forEach((k, v) -> {
                        PData d = new PData();
                        d.remainingMillis = v;
                        DATA.put(UUID.fromString(k), d);
                    });
                }
            }
        } catch (Exception e) { HeartsMod.LOGGER.error("[KriegerMod] Spielzeit laden fehlgeschlagen", e); }
        applyDailyReset();
        HeartsMod.LOGGER.info("[KriegerMod] Spielzeit-System gestartet ({} Spieler geladen) - Täglich: {} Minuten, Max. Akkumulation: {} Tage ({} Minuten)",
                DATA.size(), HeartsConfig.get().dailyMinutes, HeartsConfig.get().maxAccumulatedDays,
                HeartsConfig.get().dailyMinutes * HeartsConfig.get().maxAccumulatedDays);
    }

    public static void onServerStopping() {
        removeAllBossbars();
        saveSync();
    }

    private static PData data(UUID id) {
        return DATA.computeIfAbsent(id, k -> {
            PData d = new PData();
            d.remainingMillis = dailyMillis();
            dirty = true;
            return d;
        });
    }

    private static void applyDailyReset() {
        long today = today();
        if (lastGlobalResetDay == 0) { lastGlobalResetDay = today; dirty = true; return; }
        if (today > lastGlobalResetDay) {
            long days = today - lastGlobalResetDay;
            for (PData d : DATA.values()) {
                d.remainingMillis = Math.min(capMillis(), d.remainingMillis + days * dailyMillis());
                d.warn10 = d.warn5 = d.warn1 = false;
            }
            lastGlobalResetDay = today;
            dirty = true;
        }
    }

    public static long getRemainingMillis(UUID id) { return data(id).remainingMillis; }

    public static void setTime(UUID id, int minutes) { PData d = data(id); d.remainingMillis = minutes * 60_000L; resetFlags(d); }
    public static void addTime(UUID id, int minutes) { PData d = data(id); d.remainingMillis += minutes * 60_000L; resetFlags(d); }
    public static void resetTime(UUID id) { PData d = data(id); d.remainingMillis = dailyMillis(); resetFlags(d); }

    private static void resetFlags(PData d) { d.warn10 = d.warn5 = d.warn1 = d.grace = false; dirty = true; }

    // ---- Events -----------------------------------------------------------------------------------

    public static void onJoin(ServerPlayer p) {
        PData d = data(p.getUUID());
        if (enabled && d.remainingMillis <= 0) kick(p, false);
    }

    public static void onDisconnect(ServerPlayer p) { removeBossbar(p.getUUID()); }

    public static void tick(MinecraftServer server) {
        if (server.getTickCount() % 20 != 0) return;
        if (!enabled) return;
        applyDailyReset();
        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            PData d = data(p.getUUID());
            d.remainingMillis = Math.max(0, d.remainingMillis - 1000);
            dirty = true;
            long min = d.remainingMillis / 60_000L;
            if (d.remainingMillis > 0) {
                if (min < 10 && !d.warn10) { d.warn10 = true; Msg.send(p, "§eAchtung! Noch 10 Minuten Spielzeit."); }
                if (min < 5 && !d.warn5) { d.warn5 = true; Msg.send(p, "§eAchtung! Noch 5 Minuten Spielzeit."); }
                if (min < 1 && !d.warn1) { d.warn1 = true; Msg.send(p, "§eAchtung! Noch 1 Minute Spielzeit."); }
            }
            updateBossbar(p, d.remainingMillis);
            if (d.remainingMillis <= 0) {
                if (CombatManager.inCombat(p)) {
                    if (!d.grace) {
                        d.grace = true;
                        Msg.send(p, "§cDeine Spielzeit ist abgelaufen, aber du bist im Kampf! Du wirst gekickt, sobald der Kampf endet.");
                    }
                } else {
                    kick(p, true);
                }
            }
        }
        long now = System.currentTimeMillis();
        if (dirty && now - lastSave >= SAVE_INTERVAL_MS) {
            lastSave = now;
            Thread t = new Thread(PlaytimeManager::saveSync, "Spielzeit-Save-Thread");
            t.setDaemon(true);
            t.start();
        }
    }

    private static void kick(ServerPlayer p, boolean announce) {
        DummyManager.suppress(p.getUUID());
        if (announce) Msg.send(p, "§cDeine Spielzeit ist abgelaufen.");
        p.connection.disconnect(Component.literal(
                "§cDeine Spielzeit ist abgelaufen.\n\n§7Du kannst erst wieder beitreten, wenn du neue Spielzeit hast."));
    }

    // ---- Bossbar ----------------------------------------------------------------------------------

    private static void updateBossbar(ServerPlayer p, long remaining) {
        if (!bossbarEnabled) return;
        ServerBossEvent bar = BOSSBARS.computeIfAbsent(p.getUUID(), id -> {
            ServerBossEvent b = new ServerBossEvent(Component.literal("§6Verbleibende Spielzeit"),
                    BossEvent.BossBarColor.YELLOW, BossEvent.BossBarOverlay.PROGRESS);
            b.addPlayer(p);
            return b;
        });
        bar.setName(Component.literal("§6Spielzeit: §e" + (remaining / 60_000L) + "m " + ((remaining / 1000L) % 60) + "s"));
        bar.setProgress(Math.max(0f, Math.min(1f, remaining / (float) dailyMillis())));
    }

    private static void removeBossbar(UUID id) {
        ServerBossEvent b = BOSSBARS.remove(id);
        if (b != null) b.removeAllPlayers();
    }

    private static void removeAllBossbars() {
        BOSSBARS.values().forEach(ServerBossEvent::removeAllPlayers);
        BOSSBARS.clear();
    }

    // ---- Speichern --------------------------------------------------------------------------------

    private static synchronized void saveSync() {
        try {
            Save s = new Save();
            s.lastGlobalResetDay = lastGlobalResetDay;
            s.enabled = enabled;
            s.bossbar = bossbarEnabled;
            DATA.forEach((k, v) -> s.remaining.put(k.toString(), v.remainingMillis));
            Files.writeString(file(), GSON.toJson(s));
            dirty = false;
        } catch (Exception e) { HeartsMod.LOGGER.error("[KriegerMod] Spielzeit speichern fehlgeschlagen", e); }
    }
}
