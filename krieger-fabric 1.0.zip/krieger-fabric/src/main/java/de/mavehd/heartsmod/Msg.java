package de.mavehd.heartsmod;

import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

/** Chat-Helfer. Alle Texte sind Klartext (kein Lang-Key), damit die Mod auch ohne Client-Mod funktioniert. */
public final class Msg {
    public static final String TAG = "[§bKrieger§f] ";

    private Msg() {}

    public static void send(ServerPlayer p, String text) {
        p.sendSystemMessage(Component.literal(text));
    }

    public static void actionbar(ServerPlayer p, String text) {
        p.displayClientMessage(Component.literal(text), true);
    }

    public static void broadcast(MinecraftServer server, String text) {
        server.getPlayerList().broadcastSystemMessage(Component.literal(text), false);
    }

    public static String name(ServerPlayer p) {
        return p.getName().getString();
    }

    public static MinecraftServer server(ServerPlayer p) {
        return p.level().getServer();
    }
}
