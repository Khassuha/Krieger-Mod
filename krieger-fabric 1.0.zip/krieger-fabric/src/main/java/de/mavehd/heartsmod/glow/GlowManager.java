package de.mavehd.heartsmod.glow;

import de.mavehd.heartsmod.Msg;
import de.mavehd.heartsmod.combat.CombatManager;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/** Alle 10 Minuten leuchten alle Spieler fuer 1 Minute (im Kampf pausiert). */
public final class GlowManager {
    private static final int INTERVAL_TICKS = 12000;
    private static final int DURATION_TICKS = 1200;

    private static boolean enabled = true;
    private static int timer;
    private static boolean active;
    private static int glowEnd;
    private static final Set<UUID> APPLIED = new HashSet<>();
    private static final Set<UUID> PAUSED = new HashSet<>();

    private GlowManager() {}

    public static boolean isEnabled() { return enabled; }

    public static void setEnabled(boolean v) {
        enabled = v;
        if (!v) { active = false; timer = 0; PAUSED.clear(); }
    }

    public static void tick(MinecraftServer server) {
        if (!enabled) return;
        timer++;
        if (!active) {
            int remaining = INTERVAL_TICKS - timer;
            if (remaining == 5 * 60 * 20) Msg.broadcast(server, "Glow-Effekt in: 5 min.");
            if (remaining == 2 * 60 * 20) Msg.broadcast(server, "Glow-Effekt in: 2 min.");
            if (remaining == 60 * 20) Msg.broadcast(server, "Glow-Effekt in: 1 min.");
            if (remaining == 30 * 20) Msg.broadcast(server, "§cWARNUNG: Der Glow-Effekt startet in 30 Sekunden!");
            if (remaining > 0 && remaining <= 5 * 20 && remaining % 20 == 0) {
                for (ServerPlayer p : server.getPlayerList().getPlayers()) {
                    Msg.actionbar(p, "§eGLOW IN: " + (remaining / 20));
                }
            }
            if (timer >= INTERVAL_TICKS) {
                active = true;
                glowEnd = timer + DURATION_TICKS;
                Msg.broadcast(server, "§eAlle Spieler haben jetzt für 1 Minute den Glow-Effekt! Loggt euch NICHT aus.");
            }
            return;
        }

        if (timer % 10 == 0) {
            int left = glowEnd - timer;
            for (ServerPlayer p : server.getPlayerList().getPlayers()) {
                if (CombatManager.inCombat(p)) {
                    if (PAUSED.add(p.getUUID())) {
                        p.removeEffect(MobEffects.GLOWING);
                        APPLIED.remove(p.getUUID());
                        Msg.actionbar(p, "§cDu bist im Kampf - Glow Effekt pausiert");
                    }
                } else {
                    if (PAUSED.remove(p.getUUID())) Msg.actionbar(p, "§aKampf beendet - Glow Effekt wieder aktiv");
                    p.addEffect(new MobEffectInstance(MobEffects.GLOWING, Math.max(20, left), 0, false, false));
                    APPLIED.add(p.getUUID());
                }
            }
        }
        if (timer >= glowEnd) {
            for (UUID id : APPLIED) {
                ServerPlayer p = server.getPlayerList().getPlayer(id);
                if (p != null) p.removeEffect(MobEffects.GLOWING);
            }
            APPLIED.clear();
            PAUSED.clear();
            active = false;
            timer = 0;
            Msg.broadcast(server, "§aGlow-Effekt beendet!");
        }
    }
}
