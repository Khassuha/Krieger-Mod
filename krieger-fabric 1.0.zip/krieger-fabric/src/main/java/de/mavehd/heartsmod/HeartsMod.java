package de.mavehd.heartsmod;

import de.mavehd.heartsmod.cmd.ModCommands;
import de.mavehd.heartsmod.combat.CombatManager;
import de.mavehd.heartsmod.combat.InventorySplit;
import de.mavehd.heartsmod.config.HeartsConfig;
import de.mavehd.heartsmod.duel.DuelManager;
import de.mavehd.heartsmod.dummy.DummyManager;
import de.mavehd.heartsmod.event.LifesaverEvent;
import de.mavehd.heartsmod.glow.GlowManager;
import de.mavehd.heartsmod.logger.Webhook;
import de.mavehd.heartsmod.net.Net;
import de.mavehd.heartsmod.net.StartVideoPayload;
import de.mavehd.heartsmod.net.SyncDuelPayload;
import de.mavehd.heartsmod.net.SyncLivesPayload;
import de.mavehd.heartsmod.playtime.PlaytimeManager;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Rarity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class HeartsMod implements ModInitializer {
    public static final String MOD_ID = "heartsmod";
    public static final String VERSION = "0.0.8-fabric";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static Item LIFESAVER;
    public static SoundEvent ANIMATION_SOUND;

    @Override
    public void onInitialize() {
        HeartsConfig.load();
        LivesManager.load();
        DuelManager.load();
        DummyManager.load();

        // Registries
        ResourceLocation itemId = ResourceLocation.fromNamespaceAndPath(MOD_ID, "lifesaver");
        ResourceKey<Item> itemKey = ResourceKey.create(Registries.ITEM, itemId);
        LIFESAVER = Registry.register(BuiltInRegistries.ITEM, itemKey,
                new Item(new Item.Properties().setId(itemKey).stacksTo(1).rarity(Rarity.EPIC)));
        ResourceLocation soundId = ResourceLocation.fromNamespaceAndPath(MOD_ID, "animation_sound");
        ANIMATION_SOUND = Registry.register(BuiltInRegistries.SOUND_EVENT, soundId,
                SoundEvent.createVariableRangeEvent(soundId));

        Net.registerPayloads();
        CommandRegistrationCallback.EVENT.register((dispatcher, ctx, env) -> ModCommands.register(dispatcher));

        // Lifecycle
        ServerLifecycleEvents.SERVER_STARTED.register(server -> {
            PlaytimeManager.onServerStarted(server);
            Webhook.serverStart();
        });
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
            DummyManager.onServerStopping(server);
            PlaytimeManager.onServerStopping();
            LivesManager.save();
            DuelManager.save();
        });
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            CombatManager.tick(server);
            DummyManager.tick(server);
            PlaytimeManager.tick(server);
            GlowManager.tick(server);
            LifesaverEvent.tick(server);
        });

        // Join / Leave
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            ServerPlayer p = handler.getPlayer();
            LivesManager.rememberName(p.getUUID(), Msg.name(p));
            if (LivesManager.get(p.getUUID()) <= 0) { LivesManager.eliminate(p); return; }
            PlaytimeManager.onJoin(p);
            DummyManager.onJoin(p);
            LifesaverEvent.onJoin(p);
            Net.send(p, new SyncLivesPayload(LivesManager.get(p.getUUID())));
            Net.send(p, new SyncDuelPayload(false));
        });
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            ServerPlayer p = handler.getPlayer();
            DummyManager.onDisconnect(p);
            DuelManager.onDisconnect(p);
            PlaytimeManager.onDisconnect(p);
            CombatManager.clear(p.getUUID());
        });

        // Schaden: Duell-Regeln + Kampfmodus
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {
            if (!(entity instanceof ServerPlayer victim)) return true;
            if (!(source.getEntity() instanceof ServerPlayer attacker) || attacker == victim) return true;

            boolean aIn = DuelManager.isInDuel(attacker.getUUID());
            boolean vIn = DuelManager.isInDuel(victim.getUUID());
            if (aIn || vIn) {
                if (!DuelManager.isPair(attacker.getUUID(), victim.getUUID())) {
                    DuelManager.blockedMessage(attacker, "§cDu kannst nur deinen Duell-Gegner angreifen!");
                    return false;
                }
                // Letaler Treffer im Duell -> kein echter Tod, Duell endet
                if (amount >= victim.getHealth() + victim.getAbsorptionAmount()) {
                    victim.setHealth(victim.getMaxHealth());
                    DuelManager.end(Msg.server(victim), attacker.getUUID(), victim.getUUID(), attacker);
                    return false;
                }
                return true; // Duell: kein Kampfmodus
            }
            CombatManager.tag(attacker, victim);
            return true;
        });

        // Tod eines Spielers: Leben, Lifesaver, Inventar-Split, Animation
        ServerLivingEntityEvents.ALLOW_DEATH.register((entity, source, amount) -> {
            if (entity instanceof ServerPlayer p) handlePlayerDeath(p, source);
            return true;
        });
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            DummyManager.onDeath(entity, source);
            LifesaverEvent.onDeath(entity, source);
        });
        ServerPlayerEvents.AFTER_RESPAWN.register((oldP, newP, alive) -> {
            InventorySplit.restore(newP);
            if (LivesManager.get(newP.getUUID()) <= 0) { LivesManager.eliminate(newP); return; }
            Net.send(newP, new SyncLivesPayload(LivesManager.get(newP.getUUID())));
        });

        // Enderperlen- und Spinnenweben-Limit im Kampf
        UseItemCallback.EVENT.register((player, level, hand) -> {
            ItemStack s = player.getItemInHand(hand);
            if (s.is(Items.ENDER_PEARL) && player instanceof ServerPlayer sp && !CombatManager.tryEnderPearl(sp)) {
                return InteractionResult.FAIL;
            }
            return InteractionResult.PASS;
        });
        UseBlockCallback.EVENT.register((player, level, hand, hit) -> {
            ItemStack s = player.getItemInHand(hand);
            if (s.is(Items.COBWEB) && player instanceof ServerPlayer sp && !CombatManager.tryCobweb(sp)) {
                return InteractionResult.FAIL;
            }
            return InteractionResult.PASS;
        });

        LOGGER.info("[KriegerMod] Fabric-Port {} geladen.", VERSION);
    }

    private static void handlePlayerDeath(ServerPlayer p, DamageSource source) {
        var server = Msg.server(p);
        ServerPlayer killer = null;
        if (source.getEntity() instanceof ServerPlayer k && k != p) killer = k;
        else {
            var last = CombatManager.lastAttacker(server, p.getUUID());
            if (last != null) killer = server.getPlayerList().getPlayer(last);
        }

        // Lifesaver im Inventar rettet vor dem Lebensverlust
        for (int i = 0; i < p.getInventory().getContainerSize(); i++) {
            ItemStack s = p.getInventory().getItem(i);
            if (s.is(LIFESAVER)) {
                s.shrink(1);
                Msg.send(p, "§aDein Lifesaver hat dich vor dem Verlust eines Lebens bewahrt!");
                CombatManager.clear(p.getUUID());
                return;
            }
        }

        if (killer != null) InventorySplit.saveHalf(p);
        int left = LivesManager.loseLife(server, p.getUUID());
        String cause = killer != null ? "PvP durch " + Msg.name(killer) : source.getMsgId();
        Webhook.lifeLoss(p, cause, left);

        String base = killer != null
                ? Msg.TAG + "§c" + Msg.name(p) + "§7 wurde von §a" + Msg.name(killer) + "§7 getötet"
                : Msg.TAG + "§c" + Msg.name(p) + "§7 ist gestorben";
        Msg.broadcast(server, base + (left <= 0 ? " §c(keine Leben mehr)" : " §7(§c" + left + " §7Leben übrig)"));
        Net.send(p, new StartVideoPayload());
        CombatManager.clear(p.getUUID());
    }
}
