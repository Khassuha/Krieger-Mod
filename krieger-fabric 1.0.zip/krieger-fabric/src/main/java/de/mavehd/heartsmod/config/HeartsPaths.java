package de.mavehd.heartsmod.config;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/** Zentraler Speicherort fuer alle JSON-Dateien der Mod: config/heartsmod/ */
public final class HeartsPaths {
    private static Path dir;

    private HeartsPaths() {}

    public static Path dir() {
        if (dir == null) {
            dir = FabricLoader.getInstance().getConfigDir().resolve("heartsmod");
            try { Files.createDirectories(dir); } catch (IOException ignored) {}
        }
        return dir;
    }
}
