package de.mavehd.heartsmod.client;

public final class ClientData {
    public static int lives = -1;
    public static boolean inDuel;

    private ClientData() {}

    public static void reset() { lives = -1; inDuel = false; }
}
