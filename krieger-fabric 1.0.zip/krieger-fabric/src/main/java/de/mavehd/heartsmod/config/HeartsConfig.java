package de.mavehd.heartsmod.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import de.mavehd.heartsmod.HeartsMod;

import java.nio.file.Files;
import java.nio.file.Path;

/** Entspricht kriegermod-config.toml der Forge-Version, jetzt als JSON. */
public class HeartsConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static HeartsConfig INSTANCE = new HeartsConfig();

    public boolean enderPearlLimitEnabled = true;
    public int maxEnderPearls = 32;
    public boolean cobwebLimitEnabled = true;
    public int maxCobwebs = 64;
    /** Dauer des Kampfmodus in Sekunden (halbe Minute). */
    public int combatSeconds = 30;

    public boolean publicWebhookEnabled = false;
    public String publicWebhookUrl = "";
    public boolean logLifeLoss = true;
    public boolean logLifeChange = true;
    public boolean logPlayerEliminated = true;
    public boolean logCombatLogout = true;
    public boolean logServerStart = true;
    public boolean logDummyKill = true;

    public int dailyMinutes = 180;
    public int maxAccumulatedDays = 7;

    public static HeartsConfig get() { return INSTANCE; }

    public static void load() {
        Path file = HeartsPaths.dir().resolve("kriegermod-config.json");
        try {
            if (Files.exists(file)) {
                HeartsConfig c = GSON.fromJson(Files.readString(file), HeartsConfig.class);
                if (c != null) INSTANCE = c;
            }
            Files.writeString(file, GSON.toJson(INSTANCE)); // fehlende Felder ergaenzen
            HeartsMod.LOGGER.info("[KriegerMod] Config Loaded Successfully!");
        } catch (Exception e) {
            HeartsMod.LOGGER.error("[KriegerMod] Config Loading Failed!", e);
        }
    }
}
