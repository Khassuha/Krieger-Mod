package de.mavehd.heartsmod.cmd;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import de.mavehd.heartsmod.LivesManager;
import de.mavehd.heartsmod.duel.DuelManager;
import de.mavehd.heartsmod.event.LifesaverEvent;
import de.mavehd.heartsmod.glow.GlowManager;
import de.mavehd.heartsmod.playtime.PlaytimeManager;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

import java.util.UUID;

public final class ModCommands {
    private ModCommands() {}

    private static boolean op(CommandSourceStack s) { return s.hasPermission(2); }

    private static void ok(CommandSourceStack s, String msg) { s.sendSuccess(() -> Component.literal(msg), false); }

    private static UUID resolve(CommandSourceStack s, String name) {
        ServerPlayer online = s.getServer().getPlayerList().getPlayerByName(name);
        if (online != null) return online.getUUID();
        return LivesManager.byName(name);
    }

    public static void register(CommandDispatcher<CommandSourceStack> d) {
        registerLives(d);
        registerDuel(d);
        registerPlaytime(d);
        registerMisc(d);
    }

    // ---- /playerlives, /restoreplayer -----------------------------------------------------------

    private static void registerLives(CommandDispatcher<CommandSourceStack> d) {
        d.register(Commands.literal("playerlives")
                .then(Commands.literal("check")
                        .executes(c -> {
                            ServerPlayer p = c.getSource().getPlayerOrException();
                            ok(c.getSource(), "Du hast noch §c" + LivesManager.get(p.getUUID()) + "§f Leben.");
                            return 1;
                        })
                        .then(Commands.argument("name", StringArgumentType.word()).requires(ModCommands::op)
                                .executes(c -> {
                                    String n = StringArgumentType.getString(c, "name");
                                    UUID id = resolve(c.getSource(), n);
                                    if (id == null) { c.getSource().sendFailure(Component.literal("Spieler unbekannt: " + n)); return 0; }
                                    ok(c.getSource(), n + " hat noch §c" + LivesManager.get(id) + "§f Leben.");
                                    return 1;
                                })))
                .then(Commands.literal("set").requires(ModCommands::op)
                        .then(Commands.argument("name", StringArgumentType.word())
                                .then(Commands.argument("lives", IntegerArgumentType.integer(0, 20))
                                        .executes(c -> {
                                            String n = StringArgumentType.getString(c, "name");
                                            UUID id = resolve(c.getSource(), n);
                                            if (id == null) { c.getSource().sendFailure(Component.literal("Spieler unbekannt: " + n)); return 0; }
                                            int lives = IntegerArgumentType.getInteger(c, "lives");
                                            LivesManager.set(c.getSource().getServer(), id, lives, c.getSource().getTextName());
                                            ok(c.getSource(), n + " hat jetzt §c" + lives + "§f Leben.");
                                            return 1;
                                        })))));

        d.register(Commands.literal("restoreplayer").requires(ModCommands::op)
                .then(Commands.argument("name", StringArgumentType.word()).executes(c -> {
                    String n = StringArgumentType.getString(c, "name");
                    UUID id = resolve(c.getSource(), n);
                    if (id == null) { c.getSource().sendFailure(Component.literal("Spieler unbekannt: " + n)); return 0; }
                    LivesManager.set(c.getSource().getServer(), id, LivesManager.DEFAULT_LIVES, c.getSource().getTextName());
                    ok(c.getSource(), n + " wurde wiederhergestellt (" + LivesManager.DEFAULT_LIVES + " Leben).");
                    return 1;
                })));
    }

    // ---- /duel --------------------------------------------------------------------------------------

    private static void registerDuel(CommandDispatcher<CommandSourceStack> d) {
        d.register(Commands.literal("duel")
                .then(Commands.literal("accept").then(Commands.argument("player", EntityArgument.player()).executes(c -> {
                    DuelManager.accept(c.getSource().getPlayerOrException(), EntityArgument.getPlayer(c, "player"));
                    return 1;
                })))
                .then(Commands.literal("deny").then(Commands.argument("player", EntityArgument.player()).executes(c -> {
                    DuelManager.deny(c.getSource().getPlayerOrException(), EntityArgument.getPlayer(c, "player"));
                    return 1;
                })))
                .then(Commands.literal("on").requires(ModCommands::op).executes(c -> {
                    DuelManager.setEnabled(true); ok(c.getSource(), "Duel-System aktiviert."); return 1;
                }))
                .then(Commands.literal("off").requires(ModCommands::op).executes(c -> {
                    DuelManager.setEnabled(false); ok(c.getSource(), "Duel-System deaktiviert."); return 1;
                }))
                .then(Commands.literal("reset").requires(ModCommands::op).executes(c -> {
                    DuelManager.resetAllUsage(); ok(c.getSource(), "Duell-Limits zurückgesetzt."); return 1;
                }))
                .then(Commands.argument("player", EntityArgument.player()).executes(c -> {
                    DuelManager.request(c.getSource().getPlayerOrException(), EntityArgument.getPlayer(c, "player"));
                    return 1;
                })));
    }

    // ---- /spielzeit ---------------------------------------------------------------------------------

    private static String fmt(long ms) { return (ms / 60_000L) + "m " + ((ms / 1000L) % 60) + "s"; }

    private static void registerPlaytime(CommandDispatcher<CommandSourceStack> d) {
        d.register(Commands.literal("spielzeit")
                .executes(c -> {
                    ServerPlayer p = c.getSource().getPlayerOrException();
                    ok(c.getSource(), "§6Verbleibende Spielzeit: §e" + fmt(PlaytimeManager.getRemainingMillis(p.getUUID())));
                    return 1;
                })
                .then(Commands.literal("on").requires(ModCommands::op).executes(c -> {
                    PlaytimeManager.setEnabled(true); ok(c.getSource(), "Spielzeit-System aktiviert."); return 1;
                }))
                .then(Commands.literal("off").requires(ModCommands::op).executes(c -> {
                    PlaytimeManager.setEnabled(false); ok(c.getSource(), "Spielzeit-System deaktiviert."); return 1;
                }))
                .then(Commands.literal("bossbar").requires(ModCommands::op)
                        .then(Commands.literal("on").executes(c -> {
                            PlaytimeManager.setBossbarEnabled(true); ok(c.getSource(), "Bossbar aktiviert."); return 1;
                        }))
                        .then(Commands.literal("off").executes(c -> {
                            PlaytimeManager.setBossbarEnabled(false); ok(c.getSource(), "Bossbar deaktiviert."); return 1;
                        })))
                .then(Commands.literal("check").requires(ModCommands::op)
                        .then(Commands.argument("name", StringArgumentType.word()).executes(c -> {
                            String n = StringArgumentType.getString(c, "name");
                            UUID id = resolve(c.getSource(), n);
                            if (id == null) { c.getSource().sendFailure(Component.literal("Spieler unbekannt: " + n)); return 0; }
                            ok(c.getSource(), n + ": §e" + fmt(PlaytimeManager.getRemainingMillis(id)));
                            return 1;
                        })))
                .then(Commands.literal("reset").requires(ModCommands::op)
                        .then(Commands.argument("name", StringArgumentType.word()).executes(c -> {
                            String n = StringArgumentType.getString(c, "name");
                            UUID id = resolve(c.getSource(), n);
                            if (id == null) { c.getSource().sendFailure(Component.literal("Spieler unbekannt: " + n)); return 0; }
                            PlaytimeManager.resetTime(id);
                            ok(c.getSource(), "Spielzeit von " + n + " zurückgesetzt.");
                            return 1;
                        })))
                .then(timeOp("set", false))
                .then(timeOp("add", true)));
    }

    private static com.mojang.brigadier.builder.LiteralArgumentBuilder<CommandSourceStack> timeOp(String lit, boolean add) {
        return Commands.literal(lit).requires(ModCommands::op)
                .then(Commands.argument("name", StringArgumentType.word())
                        .then(Commands.argument("minutes", IntegerArgumentType.integer(0, 100000)).executes(c -> {
                            String n = StringArgumentType.getString(c, "name");
                            UUID id = resolve(c.getSource(), n);
                            if (id == null) { c.getSource().sendFailure(Component.literal("Spieler unbekannt: " + n)); return 0; }
                            int m = IntegerArgumentType.getInteger(c, "minutes");
                            if (add) PlaytimeManager.addTime(id, m); else PlaytimeManager.setTime(id, m);
                            ok(c.getSource(), "Spielzeit von " + n + " ist jetzt §e" + fmt(PlaytimeManager.getRemainingMillis(id)));
                            return 1;
                        })));
    }

    // ---- /glow, /lifesaverevent ---------------------------------------------------------------------

    private static void registerMisc(CommandDispatcher<CommandSourceStack> d) {
        d.register(Commands.literal("glow").requires(ModCommands::op)
                .then(Commands.literal("on").executes(c -> { GlowManager.setEnabled(true); ok(c.getSource(), "Glow-Event aktiviert."); return 1; }))
                .then(Commands.literal("off").executes(c -> { GlowManager.setEnabled(false); ok(c.getSource(), "Glow-Event deaktiviert."); return 1; })));

        d.register(Commands.literal("lifesaverevent").requires(ModCommands::op)
                .executes(c -> {
                    if (LifesaverEvent.isActive()) { c.getSource().sendFailure(Component.literal("Das Event läuft bereits.")); return 0; }
                    LifesaverEvent.start(c.getSource().getLevel(), net.minecraft.core.BlockPos.containing(c.getSource().getPosition()));
                    return 1;
                }));
    }
}
