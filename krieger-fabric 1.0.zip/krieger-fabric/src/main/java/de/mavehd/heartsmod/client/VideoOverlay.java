package de.mavehd.heartsmod.client;

import de.mavehd.heartsmod.HeartsMod;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.resources.ResourceLocation;

/** Vollbild-Animation (28 Frames, 30 ms pro Frame) plus Sound; wird per StartVideoPayload ausgeloest. */
public final class VideoOverlay {
    private static final int FRAMES = 28;
    private static final long FRAME_DURATION_MS = 30;
    private static final ResourceLocation[] TEX = new ResourceLocation[FRAMES];

    private static boolean playing;
    private static int current;
    private static long lastFrame;

    static {
        for (int i = 0; i < FRAMES; i++) {
            TEX[i] = ResourceLocation.fromNamespaceAndPath(HeartsMod.MOD_ID,
                    String.format("textures/gui/gif/ezgif-frame-%03d.png", i + 1));
        }
    }

    private VideoOverlay() {}

    public static void start() {
        playing = true;
        current = 0;
        lastFrame = System.currentTimeMillis();
        Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(HeartsMod.ANIMATION_SOUND, 1.0f));
    }

    public static void stop() { playing = false; }

    public static void render(GuiGraphics g) {
        if (!playing) return;
        long now = System.currentTimeMillis();
        if (now - lastFrame >= FRAME_DURATION_MS) {
            int steps = (int) ((now - lastFrame) / FRAME_DURATION_MS);
            current += steps;
            lastFrame += steps * FRAME_DURATION_MS;
        }
        if (current >= FRAMES) { playing = false; return; }
        int w = g.guiWidth(), h = g.guiHeight();
        g.blit(RenderPipelines.GUI_TEXTURED, TEX[current], 0, 0, 0f, 0f, w, h, 1920, 1080, 1920, 1080);
    }
}
