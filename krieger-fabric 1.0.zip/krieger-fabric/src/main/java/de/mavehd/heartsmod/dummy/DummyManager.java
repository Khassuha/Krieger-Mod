package de.mavehd.heartsmod.dummy;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import de.mavehd.heartsmod.HeartsMod;
import de.mavehd.heartsmod.LivesManager;
import de.mavehd.heartsmod.Msg;
import de.mavehd.heartsmod.combat.CombatManager;
import de.mavehd.heartsmod.combat.InventorySplit;
import de.mavehd.heartsmod.config.HeartsPaths;
import de.mavehd.heartsmod.logger.Webhook;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

/**
 * Combat-Log-Dummy. Loggt sich ein Spieler im Kampf aus, spawnt ein Mannequin (Vanilla ab 1.21.9)
 * mit seinem Skin, Glowing und seiner Ausruestung fuer 15 s. Wird es getoetet, verliert der Spieler
 * 1 Leben und 50 % seines Inventars droppen; beim naechsten Login werden diese Slots entfernt.
 */
public final class DummyManager {
    public static final String TAG = "heartsmod_dummy";
    private static final int LIFETIME_TICKS = 15 * 20;

    private static final class Dummy {
        UUID player, entity;
        ResourceKey<Level> dim;
        long expireTick;
        String name;
        int chunkX, chunkZ;
        Map<Integer, ItemStack> items = new HashMap<>();
    }

    public static class State {
        public float health = -1;
        public boolean killed;
        public List<Integer> droppedSlots = new ArrayList<>();
        public String killer;
    }

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Type STATE_TYPE = new TypeToken<Map<String, State>>() {}.getType();
    private static final Map<UUID, Dummy> BY_PLAYER = new HashMap<>();
    private static final Map<UUID, UUID> ENTITY_TO_PLAYER = new HashMap<>();
    private static final Map<String, State> STATE = new HashMap<>();
    private static final Set<UUID> SUPPRESS = new HashSet<>();
    private static boolean stopping;

    private DummyManager() {}

    private static Path stateFile() { return HeartsPaths.dir().resolve("dummy_state.json"); }
    private static Path logFile() { return HeartsPaths.dir().resolve("dummylog.json"); }

    public static void load() {
        try {
            if (Files.exists(stateFile())) {
                Map<String, State> raw = GSON.fromJson(Files.readString(stateFile()), STATE_TYPE);
                if (raw != null) STATE.putAll(raw);
            }
        } catch (Exception e) { HeartsMod.LOGGER.error("[KriegerMod] dummy_state laden fehlgeschlagen", e); }
    }

    private static void saveState() {
        try { Files.writeString(stateFile(), GSON.toJson(STATE)); }
        catch (Exception e) { HeartsMod.LOGGER.error("[KriegerMod] dummy_state speichern fehlgeschlagen", e); }
    }

    private static synchronized void log(String type, String player, String detail) {
        HeartsMod.LOGGER.info("[KriegerMod] Dummy {}: {} {}", type, player, detail);
        try {
            List<Map<String, String>> list = new ArrayList<>();
            if (Files.exists(logFile())) {
                List<Map<String, String>> old = GSON.fromJson(Files.readString(logFile()),
                        new TypeToken<List<Map<String, String>>>() {}.getType());
                if (old != null) list = old;
            }
            Map<String, String> e = new LinkedHashMap<>();
            e.put("time", LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
            e.put("type", type);
            e.put("player", player);
            e.put("detail", detail);
            list.add(e);
            Files.writeString(logFile(), GSON.toJson(list));
        } catch (Exception ex) { HeartsMod.LOGGER.warn("[HeartsMod] Konnte Dummy-Log nicht schreiben: {}", ex.toString()); }
    }

    /** Fuer Kicks (Elimination, Spielzeit): kein Dummy beim naechsten Disconnect. */
    public static void suppress(UUID id) { SUPPRESS.add(id); }

    public static boolean isDummy(Entity e) { return ENTITY_TO_PLAYER.containsKey(e.getUUID()); }

    private static String uuidArr(UUID u) {
        long m = u.getMostSignificantBits(), l = u.getLeastSignificantBits();
        return "[I;" + (int) (m >> 32) + "," + (int) m + "," + (int) (l >> 32) + "," + (int) l + "]";
    }

    // ---- Spawn beim Disconnect ---------------------------------------------------------------

    public static void onDisconnect(ServerPlayer p) {
        MinecraftServer server = Msg.server(p);
        if (stopping) return;
        if (SUPPRESS.remove(p.getUUID())) return;
        if (!CombatManager.inCombat(server, p.getUUID())) return;
        if (LivesManager.get(p.getUUID()) <= 0) return;

        Webhook.combatLogout(p);
        ServerLevel level = (ServerLevel) p.level();
        UUID dummyId = UUID.randomUUID();
        String name = Msg.name(p);
        String cmd = String.format(Locale.ROOT,
                "summon minecraft:mannequin %.3f %.3f %.3f {UUID:%s,profile:{name:\"%s\",id:%s},"
                        + "hide_description:1b,immovable:1b,Glowing:1b,CustomName:\"%s\",CustomNameVisible:1b,"
                        + "Rotation:[%.1ff,0.0f],Tags:[\"%s\"]}",
                p.getX(), p.getY(), p.getZ(), uuidArr(dummyId), name, uuidArr(p.getUUID()), name,
                p.getYRot(), TAG);
        CommandSourceStack src = server.createCommandSourceStack().withSuppressedOutput().withLevel(level);
        server.getCommands().performPrefixedCommand(src, cmd);

        Entity e = level.getEntity(dummyId);
        if (!(e instanceof LivingEntity dummy)) {
            HeartsMod.LOGGER.warn("[KriegerMod] Dummy konnte nicht gespawnt werden (Befehl: {})", cmd);
            return;
        }
        for (EquipmentSlot slot : EquipmentSlot.values()) {
            ItemStack s = p.getItemBySlot(slot);
            if (!s.isEmpty()) dummy.setItemSlot(slot, s.copy());
        }
        if (dummy.getAttribute(Attributes.MAX_HEALTH) != null) {
            dummy.getAttribute(Attributes.MAX_HEALTH).setBaseValue(p.getMaxHealth());
        }
        dummy.setHealth(p.getHealth());

        Dummy d = new Dummy();
        d.player = p.getUUID();
        d.entity = dummyId;
        d.dim = level.dimension();
        d.name = name;
        d.expireTick = server.getTickCount() + LIFETIME_TICKS;
        d.chunkX = ((int) Math.floor(p.getX())) >> 4;
        d.chunkZ = ((int) Math.floor(p.getZ())) >> 4;
        for (int i = 0; i < p.getInventory().getContainerSize(); i++) {
            ItemStack s = p.getInventory().getItem(i);
            if (!s.isEmpty()) d.items.put(i, s.copy());
        }
        level.setChunkForced(d.chunkX, d.chunkZ, true);
        BY_PLAYER.put(d.player, d);
        ENTITY_TO_PLAYER.put(dummyId, d.player);
        log("spawn", name, "15s, HP " + p.getHealth() + "/" + p.getMaxHealth());
    }

    // ---- Tick / Despawn -----------------------------------------------------------------------

    public static void tick(MinecraftServer server) {
        if (BY_PLAYER.isEmpty()) return;
        for (Dummy d : new ArrayList<>(BY_PLAYER.values())) {
            ServerLevel level = server.getLevel(d.dim);
            Entity e = level == null ? null : level.getEntity(d.entity);
            if (e == null || e.isRemoved()) { forget(d, level); continue; }
            if (server.getTickCount() >= d.expireTick) {
                State st = STATE.computeIfAbsent(d.player.toString(), k -> new State());
                if (e instanceof LivingEntity le) st.health = le.getHealth();
                saveState();
                e.discard();
                forget(d, level);
                log("despawn", d.name, "nach 15s despawned. Leben gespeichert.");
            }
        }
    }

    private static void forget(Dummy d, ServerLevel level) {
        BY_PLAYER.remove(d.player);
        ENTITY_TO_PLAYER.remove(d.entity);
        if (level != null) {
            level.setChunkForced(d.chunkX, d.chunkZ, false);
            log("chunk", d.name, "Forced-Chunk freigegeben.");
        }
    }

    public static void onServerStopping(MinecraftServer server) {
        stopping = true;
        for (Dummy d : new ArrayList<>(BY_PLAYER.values())) {
            ServerLevel level = server.getLevel(d.dim);
            Entity e = level == null ? null : level.getEntity(d.entity);
            if (e != null) e.discard();
            forget(d, level);
        }
        HeartsMod.LOGGER.info("[KriegerMod] Alle Dummys beim Serverstop entfernt.");
    }

    // ---- Tod des Dummys ------------------------------------------------------------------------

    public static void onDeath(LivingEntity entity, DamageSource source) {
        UUID pid = ENTITY_TO_PLAYER.get(entity.getUUID());
        if (pid == null) return;
        Dummy d = BY_PLAYER.get(pid);
        if (d == null) return;
        MinecraftServer server = entity.level().getServer();
        ServerLevel level = (ServerLevel) entity.level();

        String killerName = "Unbekannt";
        if (source.getEntity() instanceof ServerPlayer k) killerName = Msg.name(k);

        List<Integer> drop = InventorySplit.pickDropHalf(d.items);
        for (int slot : drop) {
            ItemEntity ie = new ItemEntity(level, entity.getX(), entity.getY(), entity.getZ(), d.items.get(slot).copy());
            ie.setDefaultPickUpDelay();
            level.addFreshEntity(ie);
        }
        State st = STATE.computeIfAbsent(pid.toString(), k -> new State());
        st.killed = true;
        st.droppedSlots = drop;
        st.killer = killerName;
        saveState();

        int left = LivesManager.loseLife(server, pid);
        Msg.broadcast(server, d.name + " wurde während er ausgeloggt war von " + killerName + " getötet");
        if (left <= 0) {
            Msg.broadcast(server, Msg.TAG + d.name + "§7 wurde im Kampf von §a" + killerName + "§f§7 getötet §c(keine Leben mehr)");
        }
        Webhook.dummyKilled(d.name, killerName);
        log("kill", d.name, "getötet von " + killerName);
        forget(d, level);
    }

    // ---- Login ------------------------------------------------------------------------------------

    public static void onJoin(ServerPlayer p) {
        UUID id = p.getUUID();
        MinecraftServer server = Msg.server(p);
        Dummy d = BY_PLAYER.get(id);
        State st = STATE.remove(id.toString());

        if (d != null) {
            ServerLevel level = server.getLevel(d.dim);
            Entity e = level == null ? null : level.getEntity(d.entity);
            if (e instanceof LivingEntity le && le.isAlive()) {
                p.setHealth(Math.min(le.getHealth(), p.getMaxHealth()));
                log("login", d.name, "hat Leben vom Dummy zurückerhalten: " + le.getHealth());
            }
            if (e != null) e.discard();
            forget(d, level);
        } else if (st != null) {
            if (st.killed) {
                for (int slot : st.droppedSlots) p.getInventory().setItem(slot, ItemStack.EMPTY);
                p.setHealth(p.getMaxHealth());
                Msg.send(p, "Dein Dummy wurde während du ausgeloggt warst getötet, 1 Leben wurde abgezogen!");
            } else if (st.health > 0) {
                p.setHealth(Math.min(st.health, p.getMaxHealth()));
                log("login", Msg.name(p), "hat gespeicherte Leben wiederhergestellt: " + st.health);
            }
        }
        saveState();
    }
}
