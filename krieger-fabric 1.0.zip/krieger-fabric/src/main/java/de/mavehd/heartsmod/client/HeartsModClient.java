package de.mavehd.heartsmod.client;

import de.mavehd.heartsmod.HeartsMod;
import de.mavehd.heartsmod.net.StartVideoPayload;
import de.mavehd.heartsmod.net.SyncDuelPayload;
import de.mavehd.heartsmod.net.SyncLivesPayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.resources.ResourceLocation;

public class HeartsModClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ClientPlayNetworking.registerGlobalReceiver(SyncLivesPayload.TYPE,
                (payload, ctx) -> ctx.client().execute(() -> ClientData.lives = payload.lives()));
        ClientPlayNetworking.registerGlobalReceiver(SyncDuelPayload.TYPE,
                (payload, ctx) -> ctx.client().execute(() -> ClientData.inDuel = payload.inDuel()));
        ClientPlayNetworking.registerGlobalReceiver(StartVideoPayload.TYPE,
                (payload, ctx) -> ctx.client().execute(VideoOverlay::start));

        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
            ClientData.reset();
            VideoOverlay.stop();
        });

        HudElementRegistry.addLast(ResourceLocation.fromNamespaceAndPath(HeartsMod.MOD_ID, "hearts"), HeartOverlay::render);
        HudElementRegistry.addLast(ResourceLocation.fromNamespaceAndPath(HeartsMod.MOD_ID, "video"),
                (g, delta) -> VideoOverlay.render(g));
        // Auch ueber Bildschirmen (z. B. Todesbildschirm) zeichnen
        ScreenEvents.AFTER_INIT.register((client, screen, w, h) ->
                ScreenEvents.afterRender(screen).register((s, g, mx, my, dt) -> VideoOverlay.render(g)));
    }
}
