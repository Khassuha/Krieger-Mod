package de.mavehd.heartsmod;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import de.mavehd.heartsmod.config.HeartsPaths;
import de.mavehd.heartsmod.dummy.DummyManager;
import de.mavehd.heartsmod.logger.Webhook;
import de.mavehd.heartsmod.net.Net;
import de.mavehd.heartsmod.net.SyncLivesPayload;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

import java.io.IOException;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Leben pro Spieler (playerLives.json). 0 Leben = ausgeschieden. */
public final class LivesManager {
    public static final int DEFAULT_LIVES = 3;
    public static final String KICK_MESSAGE =
            "§fDu hast alle Herzen verloren und bist damit aus dem Projekt ausgeschieden!";

    public static class Entry {
        public String name = "Unbekannt";
        public int lives = DEFAULT_LIVES;
    }

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Type TYPE = new TypeToken<Map<String, Entry>>() {}.getType();
    private static final Map<UUID, Entry> DATA = new ConcurrentHashMap<>();
    private static Path file() { return HeartsPaths.dir().resolve("playerLives.json"); }

    private LivesManager() {}

    public static synchronized void load() {
        try {
            if (Files.exists(file())) {
                Map<String, Entry> raw = GSON.fromJson(Files.readString(file()), TYPE);
                if (raw != null) raw.forEach((k, v) -> DATA.put(UUID.fromString(k), v));
                HeartsMod.LOGGER.info("[KriegerMod] Successfully loaded player data for {} players", DATA.size());
            } else {
                save();
                HeartsMod.LOGGER.info("[KriegerMod] Created new player data file at {}", file());
            }
        } catch (Exception e) {
            HeartsMod.LOGGER.error("[KriegerMod] Error loading playerLives!", e);
        }
    }

    public static synchronized void save() {
        try {
            Map<String, Entry> raw = new HashMap<>();
            DATA.forEach((k, v) -> raw.put(k.toString(), v));
            Files.writeString(file(), GSON.toJson(raw));
        } catch (IOException e) {
            HeartsMod.LOGGER.error("[KriegerMod] Failed to save playerLives", e);
        }
    }

    public static int get(UUID id) {
        return DATA.computeIfAbsent(id, k -> new Entry()).lives;
    }

    public static void rememberName(UUID id, String name) {
        Entry e = DATA.computeIfAbsent(id, k -> new Entry());
        if (!name.equals(e.name)) { e.name = name; save(); }
    }

    public static String nameOf(UUID id) {
        Entry e = DATA.get(id);
        return e == null ? "Unbekannt" : e.name;
    }

    public static UUID byName(String name) {
        for (Map.Entry<UUID, Entry> e : DATA.entrySet()) {
            if (e.getValue().name.equalsIgnoreCase(name)) return e.getKey();
        }
        return null;
    }

    public static Map<UUID, Entry> all() { return DATA; }

    /** Setzt Leben (auch offline). changedBy = "Konsole" oder Spielername. */
    public static void set(MinecraftServer server, UUID id, int lives, String changedBy) {
        Entry e = DATA.computeIfAbsent(id, k -> new Entry());
        e.lives = Math.max(0, lives);
        save();
        Webhook.lifeChange(e.name, e.lives, changedBy);
        ServerPlayer p = server.getPlayerList().getPlayer(id);
        if (p != null) {
            Net.send(p, new SyncLivesPayload(e.lives));
            if (e.lives <= 0) eliminate(p);
        }
    }

    /** Zieht 1 Leben ab (auch offline) und liefert den neuen Stand. */
    public static int loseLife(MinecraftServer server, UUID id) {
        Entry e = DATA.computeIfAbsent(id, k -> new Entry());
        e.lives = Math.max(0, e.lives - 1);
        save();
        ServerPlayer p = server.getPlayerList().getPlayer(id);
        if (p != null) Net.send(p, new SyncLivesPayload(e.lives));
        if (e.lives <= 0) Webhook.eliminated(e.name);
        return e.lives;
    }

    public static void eliminate(ServerPlayer p) {
        DummyManager.suppress(p.getUUID());
        p.connection.disconnect(Component.literal(KICK_MESSAGE));
    }
}
