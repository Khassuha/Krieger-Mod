package de.mavehd.heartsmod.combat;

import de.mavehd.heartsmod.Msg;
import de.mavehd.heartsmod.config.HeartsConfig;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/** Kampfmodus: Timer, Actionbar, Enderperlen-/Cobweb-Limit, Merker fuer den letzten Angreifer. */
public final class CombatManager {
    private static final class Info {
        UUID lastAttacker;
        long endTick;
    }

    private static final Map<UUID, Info> INFO = new HashMap<>();
    private static final Map<UUID, Integer> PEARLS = new HashMap<>();
    private static final Map<UUID, Integer> WEBS = new HashMap<>();

    private CombatManager() {}

    public static boolean inCombat(MinecraftServer server, UUID id) {
        Info i = INFO.get(id);
        return i != null && server.getTickCount() < i.endTick;
    }

    public static boolean inCombat(ServerPlayer p) {
        return inCombat(Msg.server(p), p.getUUID());
    }

    public static UUID lastAttacker(MinecraftServer server, UUID victim) {
        Info i = INFO.get(victim);
        return (i != null && server.getTickCount() < i.endTick) ? i.lastAttacker : null;
    }

    /** Beide Spieler in den Kampf setzen. */
    public static void tag(ServerPlayer attacker, ServerPlayer victim) {
        MinecraftServer server = Msg.server(attacker);
        long end = server.getTickCount() + HeartsConfig.get().combatSeconds * 20L;

        boolean aNew = !inCombat(server, attacker.getUUID());
        boolean vNew = !inCombat(server, victim.getUUID());

        Info a = INFO.computeIfAbsent(attacker.getUUID(), k -> new Info());
        a.lastAttacker = victim.getUUID();
        a.endTick = end;
        Info v = INFO.computeIfAbsent(victim.getUUID(), k -> new Info());
        v.lastAttacker = attacker.getUUID();
        v.endTick = end;

        if (aNew) Msg.send(attacker, "§6Du hast §c" + Msg.name(victim) + "§6 angegriffen!");
        if (vNew) Msg.send(victim, "§cDu wurdest von §6" + Msg.name(attacker) + "§c angegriffen!");
    }

    public static void clear(UUID id) {
        INFO.remove(id);
        PEARLS.remove(id);
        WEBS.remove(id);
    }

    public static void tick(MinecraftServer server) {
        if (server.getTickCount() % 10 != 0) return;
        Iterator<Map.Entry<UUID, Info>> it = INFO.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Info> e = it.next();
            ServerPlayer p = server.getPlayerList().getPlayer(e.getKey());
            long left = e.getValue().endTick - server.getTickCount();
            if (left <= 0) {
                it.remove();
                PEARLS.remove(e.getKey());
                WEBS.remove(e.getKey());
                if (p != null) Msg.send(p, "§aDu bist wieder sicher. Der Kampf ist vorbei!");
            } else if (p != null) {
                Msg.actionbar(p, "§cIn Combat! §7(" + ((left + 19) / 20) + " s)");
            }
        }
    }

    /** @return true wenn der Wurf erlaubt ist. */
    public static boolean tryEnderPearl(ServerPlayer p) {
        HeartsConfig c = HeartsConfig.get();
        if (!c.enderPearlLimitEnabled || !inCombat(p)) return true;
        int used = PEARLS.getOrDefault(p.getUUID(), 0);
        if (used >= c.maxEnderPearls) {
            Msg.send(p, "Du hast das Limit von " + c.maxEnderPearls + " Enderperlen im Kampf erreicht!");
            return false;
        }
        PEARLS.put(p.getUUID(), used + 1);
        Msg.actionbar(p, "Enderperlen verbleibend: §4" + (c.maxEnderPearls - used - 1));
        return true;
    }

    /** @return true wenn das Platzieren erlaubt ist. */
    public static boolean tryCobweb(ServerPlayer p) {
        HeartsConfig c = HeartsConfig.get();
        if (!c.cobwebLimitEnabled || !inCombat(p)) return true;
        int used = WEBS.getOrDefault(p.getUUID(), 0);
        if (used >= c.maxCobwebs) {
            Msg.send(p, "Du hast das Limit von " + c.maxCobwebs + " Spinnenweben im Kampf erreicht!");
            return false;
        }
        WEBS.put(p.getUUID(), used + 1);
        Msg.actionbar(p, "Spinnenweben verbleibend: §4" + (c.maxCobwebs - used - 1));
        return true;
    }
}
