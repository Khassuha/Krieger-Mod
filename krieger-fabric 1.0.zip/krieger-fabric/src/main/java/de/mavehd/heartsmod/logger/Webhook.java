package de.mavehd.heartsmod.logger;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import de.mavehd.heartsmod.HeartsMod;
import de.mavehd.heartsmod.config.HeartsConfig;
import net.minecraft.server.level.ServerPlayer;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * Oeffentlicher Discord-Webhook (PublicWebhookLogger der Forge-Version).
 * Der ORIGINALE "WebhookLogger" mit Proxy auf 146.19.191.154 wurde bewusst NICHT portiert.
 */
public final class Webhook {
    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("dd.MM.yyyy - HH:mm:ss");
    private static final HttpClient HTTP = HttpClient.newHttpClient();
    private static final ThreadPoolExecutor EXECUTOR = new ThreadPoolExecutor(
            1, 1, 0L, TimeUnit.MILLISECONDS, new ArrayBlockingQueue<>(50),
            r -> { Thread t = new Thread(r, "KriegerMod-Webhook"); t.setDaemon(true); return t; },
            new ThreadPoolExecutor.DiscardPolicy());

    private Webhook() {}

    public static String coords(ServerPlayer p) {
        return String.format("[%s | X: %d Y: %d Z: %d]", p.level().dimension().location(),
                (int) p.getX(), (int) p.getY(), (int) p.getZ());
    }

    private static boolean enabled() {
        HeartsConfig c = HeartsConfig.get();
        return c.publicWebhookEnabled && c.publicWebhookUrl != null && !c.publicWebhookUrl.isBlank();
    }

    private static void send(String title, int color, String... lines) {
        if (!enabled()) return;
        StringBuilder sb = new StringBuilder();
        for (String l : lines) sb.append(l).append('\n');
        sb.append("Zeitpunkt: ").append(LocalDateTime.now().format(FMT));

        JsonObject embed = new JsonObject();
        embed.addProperty("title", title);
        embed.addProperty("description", sb.toString());
        embed.addProperty("color", color);
        JsonArray embeds = new JsonArray();
        embeds.add(embed);
        JsonObject body = new JsonObject();
        body.add("embeds", embeds);

        String url = HeartsConfig.get().publicWebhookUrl;
        EXECUTOR.execute(() -> {
            try {
                HttpRequest req = HttpRequest.newBuilder(URI.create(url))
                        .header("Content-Type", "application/json")
                        .timeout(java.time.Duration.ofSeconds(10))
                        .POST(HttpRequest.BodyPublishers.ofString(body.toString())).build();
                HTTP.send(req, HttpResponse.BodyHandlers.discarding());
            } catch (Exception e) {
                HeartsMod.LOGGER.warn("[KriegerMod] Webhook fehlgeschlagen: {}", e.toString());
            }
        });
    }

    public static void serverStart() {
        if (HeartsConfig.get().logServerStart) send("Server gestartet", 0x55FF55, "Mod-Version: " + HeartsMod.VERSION);
    }

    public static void lifeLoss(ServerPlayer victim, String cause, int livesLeft) {
        if (!HeartsConfig.get().logLifeLoss) return;
        send("Leben verloren", 0xFF5555, "Spieler: " + victim.getName().getString(),
                "Ursache: " + cause, "Koordinaten: " + coords(victim), "Verbleibende Leben: " + livesLeft);
    }

    public static void eliminated(String name) {
        if (!HeartsConfig.get().logPlayerEliminated) return;
        send("Spieler ausgeschieden", 0xAA0000, "Spieler: " + name);
    }

    public static void lifeChange(String name, int newLives, String changedBy) {
        if (!HeartsConfig.get().logLifeChange) return;
        send("Leben geändert", 0xFFAA00, "Spieler: " + name, "Neue Leben: " + newLives, "Geändert von: " + changedBy);
    }

    public static void combatLogout(ServerPlayer p) {
        if (!HeartsConfig.get().logCombatLogout) return;
        send("Logout im Kampf", 0xFFAA00, "Spieler: " + p.getName().getString(), "Koordinaten: " + coords(p));
    }

    public static void dummyKilled(String owner, String killer) {
        if (!HeartsConfig.get().logDummyKill) return;
        send("Dummy getötet", 0xFF5555, "Dummy von: " + owner, "Getötet von: " + killer);
    }
}
