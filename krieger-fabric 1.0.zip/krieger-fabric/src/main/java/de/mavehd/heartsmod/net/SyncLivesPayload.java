package de.mavehd.heartsmod.net;

import de.mavehd.heartsmod.HeartsMod;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

public record SyncLivesPayload(int lives) implements CustomPacketPayload {
    public static final Type<SyncLivesPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(HeartsMod.MOD_ID, "sync_lives"));
    public static final StreamCodec<RegistryFriendlyByteBuf, SyncLivesPayload> CODEC =
            StreamCodec.composite(ByteBufCodecs.VAR_INT, SyncLivesPayload::lives, SyncLivesPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }
}
